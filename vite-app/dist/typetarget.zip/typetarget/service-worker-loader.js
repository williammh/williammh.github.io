import './assets/service-worker.ts-BXx2QJAc.js';
